'use client';

import React, { useState } from 'react';
import styles from './ApplicationForm.module.css';

// تعريف أنواع البيانات
interface FormData {
  fullName: string;
  email: string;
  phone: string;
  nationalId: string;
  birthDate: string;
  gender: string;
  highSchoolType: string;
  highSchoolGrade: string;
  preferredCollege: string;
  preferredMajor: string;
  address: string;
  notes: string;
}

const ApplicationForm: React.FC = () => {
  // حالة النموذج
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    email: '',
    phone: '',
    nationalId: '',
    birthDate: '',
    gender: '',
    highSchoolType: '',
    highSchoolGrade: '',
    preferredCollege: '',
    preferredMajor: '',
    address: '',
    notes: ''
  });

  // حالة تقديم النموذج
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string>('');

  // التعامل مع تغيير قيم الحقول
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // التحقق من صحة النموذج
  const validateForm = (): boolean => {
    const requiredFields = ['fullName', 'email', 'phone', 'nationalId', 'birthDate', 'gender', 'highSchoolType', 'highSchoolGrade', 'preferredCollege'];
    
    for (const field of requiredFields) {
      if (!formData[field as keyof FormData]) {
        setErrorMessage(`الرجاء تعبئة حقل ${getFieldLabel(field)}`);
        return false;
      }
    }
    
    // التحقق من صحة البريد الإلكتروني
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setErrorMessage('الرجاء إدخال بريد إلكتروني صحيح');
      return false;
    }
    
    // التحقق من صحة رقم الهاتف
    const phoneRegex = /^\d{9,10}$/;
    if (!phoneRegex.test(formData.phone)) {
      setErrorMessage('الرجاء إدخال رقم هاتف صحيح (9-10 أرقام)');
      return false;
    }
    
    return true;
  };

  // الحصول على تسمية الحقل بالعربية
  const getFieldLabel = (fieldName: string): string => {
    const labels: Record<string, string> = {
      fullName: 'الاسم الكامل',
      email: 'البريد الإلكتروني',
      phone: 'رقم الهاتف',
      nationalId: 'رقم الهوية',
      birthDate: 'تاريخ الميلاد',
      gender: 'الجنس',
      highSchoolType: 'نوع الثانوية',
      highSchoolGrade: 'معدل الثانوية',
      preferredCollege: 'الكلية المرغوبة',
      preferredMajor: 'التخصص المرغوب',
      address: 'العنوان',
      notes: 'ملاحظات'
    };
    
    return labels[fieldName] || fieldName;
  };

  // تقديم النموذج
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // التحقق من صحة النموذج
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    setSubmitStatus('idle');
    setErrorMessage('');
    
    try {
      // هنا يمكن إضافة الاتصال بالخادم لإرسال البيانات
      // مثال: await fetch('/api/application-form', { method: 'POST', body: JSON.stringify(formData) });
      
      // محاكاة الاتصال بالخادم
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // تم التقديم بنجاح
      setSubmitStatus('success');
      
      // إعادة تعيين النموذج
      setFormData({
        fullName: '',
        email: '',
        phone: '',
        nationalId: '',
        birthDate: '',
        gender: '',
        highSchoolType: '',
        highSchoolGrade: '',
        preferredCollege: '',
        preferredMajor: '',
        address: '',
        notes: ''
      });
    } catch (error) {
      console.error('خطأ في تقديم النموذج:', error);
      setSubmitStatus('error');
      setErrorMessage('حدث خطأ أثناء تقديم الطلب. الرجاء المحاولة مرة أخرى.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className={styles.formSection} id="registration-form">
      <div className={styles.container}>
        <div className={styles.formHeader}>
          <h2 className={styles.formTitle}>نموذج طلب الالتحاق</h2>
          <p className={styles.formDescription}>
            يرجى تعبئة النموذج التالي بالمعلومات المطلوبة للتقدم بطلب الالتحاق بجامعة الريادة
          </p>
        </div>

        {submitStatus === 'success' ? (
          <div className={styles.successMessage}>
            <div className={styles.successIcon}>✓</div>
            <h3>تم تقديم طلبك بنجاح!</h3>
            <p>سيتم التواصل معك قريبًا عبر البريد الإلكتروني أو الهاتف المسجل.</p>
            <button 
              className={styles.newApplicationButton}
              onClick={() => setSubmitStatus('idle')}
            >
              تقديم طلب جديد
            </button>
          </div>
        ) : (
          <form className={styles.applicationForm} onSubmit={handleSubmit}>
            {/* البيانات الشخصية */}
            <div className={styles.formSection}>
              <h3 className={styles.sectionTitle}>البيانات الشخصية</h3>
              
              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="fullName">الاسم الكامل *</label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    placeholder="الاسم الكامل كما في الهوية"
                    required
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label htmlFor="nationalId">رقم الهوية *</label>
                  <input
                    type="text"
                    id="nationalId"
                    name="nationalId"
                    value={formData.nationalId}
                    onChange={handleChange}
                    placeholder="رقم الهوية الوطنية"
                    required
                  />
                </div>
              </div>
              
              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="birthDate">تاريخ الميلاد *</label>
                  <input
                    type="date"
                    id="birthDate"
                    name="birthDate"
                    value={formData.birthDate}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label htmlFor="gender">الجنس *</label>
                  <select
                    id="gender"
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    required
                  >
                    <option value="">اختر الجنس</option>
                    <option value="male">ذكر</option>
                    <option value="female">أنثى</option>
                  </select>
                </div>
              </div>
            </div>
            
            {/* بيانات الاتصال */}
            <div className={styles.formSection}>
              <h3 className={styles.sectionTitle}>بيانات الاتصال</h3>
              
              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="email">البريد الإلكتروني *</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="example@example.com"
                    required
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label htmlFor="phone">رقم الهاتف *</label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="7xxxxxxxx"
                    required
                  />
                </div>
              </div>
              
              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="address">العنوان</label>
                  <input
                    type="text"
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    placeholder="المدينة، الحي، الشارع"
                  />
                </div>
              </div>
            </div>
            
            {/* البيانات الأكاديمية */}
            <div className={styles.formSection}>
              <h3 className={styles.sectionTitle}>البيانات الأكاديمية</h3>
              
              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="highSchoolType">نوع الثانوية *</label>
                  <select
                    id="highSchoolType"
                    name="highSchoolType"
                    value={formData.highSchoolType}
                    onChange={handleChange}
                    required
                  >
                    <option value="">اختر نوع الثانوية</option>
                    <option value="scientific">علمي</option>
                    <option value="literary">أدبي</option>
                    <option value="commercial">تجاري</option>
                    <option value="industrial">صناعي</option>
                    <option value="other">أخرى</option>
                  </select>
                </div>
                
                <div className={styles.formGroup}>
                  <label htmlFor="highSchoolGrade">معدل الثانوية *</label>
                  <input
                    type="text"
                    id="highSchoolGrade"
                    name="highSchoolGrade"
                    value={formData.highSchoolGrade}
                    onChange={handleChange}
                    placeholder="مثال: 85.5%"
                    required
                  />
                </div>
              </div>
              
              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="preferredCollege">الكلية المرغوبة *</label>
                  <select
                    id="preferredCollege"
                    name="preferredCollege"
                    value={formData.preferredCollege}
                    onChange={handleChange}
                    required
                  >
                    <option value="">اختر الكلية</option>
                    <option value="engineering">كلية الهندسة</option>
                    <option value="medicine">كلية الطب</option>
                    <option value="business">كلية العلوم الإدارية</option>
                  </select>
                </div>
                
                <div className={styles.formGroup}>
                  <label htmlFor="preferredMajor">التخصص المرغوب</label>
                  <input
                    type="text"
                    id="preferredMajor"
                    name="preferredMajor"
                    value={formData.preferredMajor}
                    onChange={handleChange}
                    placeholder="التخصص المرغوب (اختياري)"
                  />
                </div>
              </div>
            </div>
            
            {/* ملاحظات إضافية */}
            <div className={styles.formSection}>
              <h3 className={styles.sectionTitle}>ملاحظات إضافية</h3>
              
              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="notes">ملاحظات</label>
                  <textarea
                    id="notes"
                    name="notes"
                    value={formData.notes}
                    onChange={handleChange}
                    placeholder="أي ملاحظات أو استفسارات تود إضافتها"
                    rows={4}
                  />
                </div>
              </div>
            </div>
            
            {/* رسالة الخطأ */}
            {errorMessage && (
              <div className={styles.errorMessage}>
                <p>{errorMessage}</p>
              </div>
            )}
            
            {/* أزرار التقديم */}
            <div className={styles.formActions}>
              <button 
                type="submit" 
                className={styles.submitButton}
                disabled={isSubmitting}
              >
                {isSubmitting ? 'جاري التقديم...' : 'تقديم الطلب'}
              </button>
              
              <button 
                type="reset" 
                className={styles.resetButton}
                onClick={() => {
                  setFormData({
                    fullName: '',
                    email: '',
                    phone: '',
                    nationalId: '',
                    birthDate: '',
                    gender: '',
                    highSchoolType: '',
                    highSchoolGrade: '',
                    preferredCollege: '',
                    preferredMajor: '',
                    address: '',
                    notes: ''
                  });
                  setErrorMessage('');
                }}
              >
                إعادة تعيين
              </button>
            </div>
          </form>
        )}
      </div>
    </section>
  );
};

export default ApplicationForm;
