'use client';

import React from 'react';
import styles from './UniversityIntroVideo.module.css';

const UniversityIntroVideo: React.FC = () => {
  return (
    <section className={styles.introSection}>
      <div className={styles.container}>
        <div className={styles.textContent}>
          <h2 className={styles.title}>نبذة عن الجامعة</h2>
          <p className={styles.description}>
            جامعة الريادة هي صرح أكاديمي رائد يهدف إلى تخريج كوادر متميزة في مختلف التخصصات العلمية والإدارية، مع بيئة تعليمية محفزة على الإبداع والابتكار.
          </p>
        </div>
        <div className={styles.videoWrapper}>
          <iframe
            className={styles.video}
            src="https://www.youtube.com/embed/2eA4qgV3gJU"
            title="نبذة عن الجامعة"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
      </div>
    </section>
  );
};

export default UniversityIntroVideo;
