import UniversityIntroVideo from './UniversityIntroVideo';

export default UniversityIntroVideo;
