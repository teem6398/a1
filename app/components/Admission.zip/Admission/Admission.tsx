'use client';
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import styles from './Admission.module.css';
import Navbar from '../Home/Navbar/Navbar';
import MajorsGrid from './MajorsGrid';
import HowToApply from './HowToApply';
import UniversityIntroVideo from './UniversityIntroVideo';
import ApplicationForm from './ApplicationForm';
import Footer from '../Home/Footer/footers';
const Admission = () => {
  // حالة لتتبع ما إذا كان نموذج الالتحاق مرئيًا أم لا
  const [showApplicationForm, setShowApplicationForm] = useState<boolean>(false);
  
  // التمرير إلى قسم نموذج الالتحاق
  const scrollToApplicationForm = () => {
    setShowApplicationForm(true);
    setTimeout(() => {
      const formElement = document.getElementById('registration-form');
      if (formElement) {
        formElement.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };
  return (
    <div className={styles.admissionPage}>
      {/* استدعاء مكون Navbar */}
      <Navbar />
      
      {/* قسم Hero */}
      <section className={styles.heroSection}>
        <div className={styles.heroOverlay}></div>
        <div className={styles.heroContent}>
          <motion.h1 
            className={styles.heroTitle}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            التسجيل والقبول
          </motion.h1>
          <motion.p 
            className={styles.heroSubtitle}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            خطوتك الأولى نحو مستقبل أكاديمي متميز
          </motion.p>
          <motion.div 
            className={styles.heroCta}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <button 
              onClick={scrollToApplicationForm} 
              className={styles.primaryButton}
            >
              تقديم طلب الالتحاق
            </button>
            <Link href="#admission-requirements" className={styles.secondaryButton}>
              شروط القبول
            </Link>
          </motion.div>
        </div>
        {/* هنا سيتم إضافة الصورة لاحقًا */}
        <div className={styles.heroImagePlaceholder}>
          {/* سيتم استبدال هذا بصورة حقيقية لاحقًا */}
          <div className={styles.placeholderText}>سيتم إضافة صورة هنا</div>
        </div>
      </section>
      
      {/* قسم الفيديو التعريفي عن الجامعة */}
      <UniversityIntroVideo />
      
      {/* قسم التخصصات وشروط القبول */}
      <MajorsGrid />
      
      {/* قسم خطوات التقديم */}
      <HowToApply />
      
      {/* قسم نموذج طلب الالتحاق - يظهر فقط عند الضغط على زر طلب الالتحاق */}
      {showApplicationForm && <ApplicationForm />}
      
      {/* يمكن إضافة أقسام أخرى لاحقًا */}
      <Footer />
    </div>
  );
};

export default Admission;
