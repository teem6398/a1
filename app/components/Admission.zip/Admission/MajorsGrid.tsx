'use client';
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import styles from './MajorsGrid.module.css';

// تعريف واجهة التخصص
interface Major {
  id: number;
  name: string;
  college: string;
  collegeSlug: string;
  slug: string;
  description: string;
  icon: string;
  duration: string;
  students: number;
  features: string[];
  admissionRequirements: string[];
}

// تعريف واجهة الكلية
interface College {
  id: number;
  name: string;
  slug: string;
}

const MajorsGrid = () => {
  const [majors, setMajors] = useState<Major[]>([]);
  const [colleges, setColleges] = useState<College[]>([]);
  const [selectedCollege, setSelectedCollege] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // جلب بيانات التخصصات
    const fetchMajors = async () => {
      try {
        // في الحالة الحقيقية، ستقوم بجلب البيانات من API
        // لكن هنا سنستخدم بيانات تجريبية
        const mockMajors: Major[] = [
          // كلية الهندسة
          {
            id: 1,
            name: 'هندسة معمارية',
            college: 'كلية الهندسة',
            collegeSlug: 'engineering',
            slug: 'Architecture',
            description: 'تصميم وتخطيط المباني والمنشآت المعمارية',
            icon: '🏛️',
            duration: 'بكالوريوس - 5 سنوات',
            students: 180,
            features: ['تصميم معماري', 'تخطيط عمراني', 'تقنيات البناء الحديثة'],
            admissionRequirements: [
              'الحصول على شهادة الثانوية العامة بمعدل لا يقل عن 85%',
              'اجتياز اختبار القدرات الهندسية',
              'اجتياز المقابلة الشخصية',
              'إتقان مهارات الرسم الهندسي'
            ]
          },
          {
            id: 2,
            name: 'تقنية المعلومات',
            college: 'كلية الهندسة',
            collegeSlug: 'engineering',
            slug: 'IT',
            description: 'تطوير وإدارة أنظمة تكنولوجيا المعلومات',
            icon: '💻',
            duration: 'بكالوريوس - 4 سنوات',
            students: 250,
            features: ['برمجة الحاسوب', 'شبكات الحاسوب', 'أمن المعلومات'],
            admissionRequirements: [
              'الحصول على شهادة الثانوية العامة بمعدل لا يقل عن 80%',
              'اجتياز اختبار القدرات في الرياضيات',
              'إلمام بأساسيات الحاسوب والبرمجة',
              'اجتياز المقابلة الشخصية'
            ]
          },
          
          // كلية الطب
          {
            id: 3,
            name: 'الطب البشري',
            college: 'كلية الطب',
            collegeSlug: 'medicine',
            slug: 'Medicine',
            description: 'دراسة الطب العام وتشخيص وعلاج الأمراض',
            icon: '⚕️',
            duration: 'بكالوريوس - 6 سنوات',
            students: 120,
            features: ['تشريح', 'علم الأمراض', 'طب الأسرة'],
            admissionRequirements: [
              'الحصول على شهادة الثانوية العامة بمعدل لا يقل عن 95%',
              'اجتياز اختبار القدرات الطبية',
              'اجتياز المقابلة الشخصية',
              'اجتياز الفحص الطبي',
              'إتقان اللغة الإنجليزية'
            ]
          },
          {
            id: 4,
            name: 'طب الأسنان',
            college: 'كلية الطب',
            collegeSlug: 'medicine',
            slug: 'Dentistry',
            description: 'تشخيص وعلاج أمراض الفم والأسنان',
            icon: '🦷',
            duration: 'بكالوريوس - 5 سنوات',
            students: 100,
            features: ['جراحة الفم', 'تقويم الأسنان', 'طب أسنان الأطفال'],
            admissionRequirements: [
              'الحصول على شهادة الثانوية العامة بمعدل لا يقل عن 90%',
              'اجتياز اختبار القدرات الطبية',
              'اجتياز المقابلة الشخصية',
              'إتقان اللغة الإنجليزية',
              'مهارات يدوية جيدة'
            ]
          },
          {
            id: 5,
            name: 'الصيدلة',
            college: 'كلية الطب',
            collegeSlug: 'medicine',
            slug: 'Pharmacy',
            description: 'دراسة تركيب وتصنيع وتأثير الأدوية',
            icon: '💊',
            duration: 'بكالوريوس - 5 سنوات',
            students: 150,
            features: ['كيمياء صيدلانية', 'علم الأدوية', 'صيدلة سريرية'],
            admissionRequirements: [
              'الحصول على شهادة الثانوية العامة بمعدل لا يقل عن 85%',
              'اجتياز اختبار القدرات العلمية',
              'اجتياز المقابلة الشخصية',
              'إتقان اللغة الإنجليزية'
            ]
          },
          {
            id: 6,
            name: 'المختبرات الطبية',
            college: 'كلية الطب',
            collegeSlug: 'medicine',
            slug: 'Laboratory',
            description: 'إجراء التحاليل المخبرية وتفسير نتائجها',
            icon: '🔬',
            duration: 'بكالوريوس - 4 سنوات',
            students: 130,
            features: ['علم الأحياء الدقيقة', 'علم الدم', 'الكيمياء الحيوية'],
            admissionRequirements: [
              'الحصول على شهادة الثانوية العامة بمعدل لا يقل عن 80%',
              'اجتياز اختبار القدرات العلمية',
              'اجتياز المقابلة الشخصية',
              'إتقان اللغة الإنجليزية'
            ]
          },
          
          // كلية العلوم الإدارية
          {
            id: 7,
            name: 'إدارة الأعمال',
            college: 'كلية العلوم الإدارية',
            collegeSlug: 'business',
            slug: 'BusinessManagement',
            description: 'دراسة إدارة الشركات والمؤسسات',
            icon: '📈',
            duration: 'بكالوريوس - 4 سنوات',
            students: 350,
            features: ['إدارة استراتيجية', 'ريادة الأعمال', 'إدارة الموارد البشرية'],
            admissionRequirements: [
              'الحصول على شهادة الثانوية العامة بمعدل لا يقل عن 75%',
              'اجتياز اختبار القدرات العامة',
              'اجتياز المقابلة الشخصية',
              'مهارات تواصل جيدة'
            ]
          },
          {
            id: 8,
            name: 'المحاسبة',
            college: 'كلية العلوم الإدارية',
            collegeSlug: 'business',
            slug: 'Accounting',
            description: 'دراسة تسجيل وتحليل البيانات المالية',
            icon: '📊',
            duration: 'بكالوريوس - 4 سنوات',
            students: 280,
            features: ['محاسبة مالية', 'مراجعة وتدقيق', 'محاسبة تكاليف'],
            admissionRequirements: [
              'الحصول على شهادة الثانوية العامة بمعدل لا يقل عن 75%',
              'اجتياز اختبار القدرات في الرياضيات',
              'اجتياز المقابلة الشخصية',
              'مهارات تحليلية جيدة'
            ]
          },
          {
            id: 9,
            name: 'التسويق',
            college: 'كلية العلوم الإدارية',
            collegeSlug: 'business',
            slug: 'Marketing',
            description: 'دراسة استراتيجيات الترويج وتسويق المنتجات',
            icon: '🛒',
            duration: 'بكالوريوس - 4 سنوات',
            students: 200,
            features: ['التسويق الرقمي', 'إدارة العلامات التجارية', 'سلوك المستهلك'],
            admissionRequirements: [
              'الحصول على شهادة الثانوية العامة بمعدل لا يقل عن 70%',
              'اجتياز اختبار القدرات العامة',
              'اجتياز المقابلة الشخصية',
              'مهارات إبداعية وتواصل جيدة'
            ]
          },
          {
            id: 10,
            name: 'التمويل والاستثمار',
            college: 'كلية العلوم الإدارية',
            collegeSlug: 'business',
            slug: 'Finance',
            description: 'دراسة إدارة الأموال والاستثمارات',
            icon: '💰',
            duration: 'بكالوريوس - 4 سنوات',
            students: 120,
            features: ['التحليل المالي', 'إدارة المحافظ الاستثمارية', 'التمويل الدولي'],
            admissionRequirements: [
              'الحصول على شهادة الثانوية العامة بمعدل لا يقل عن 75%',
              'اجتياز اختبار القدرات في الرياضيات',
              'اجتياز المقابلة الشخصية',
              'مهارات تحليلية جيدة'
            ]
          }
        ];

        // جلب الكليات الفريدة من التخصصات
        const uniqueColleges: College[] = [
          { id: 1, name: 'كلية الهندسة', slug: 'engineering' },
          { id: 2, name: 'كلية الطب', slug: 'medicine' },
          { id: 3, name: 'كلية العلوم الإدارية', slug: 'business' }
        ];

        setMajors(mockMajors);
        setColleges(uniqueColleges);
        setIsLoading(false);
      } catch (error) {
        console.error('خطأ في جلب بيانات التخصصات:', error);
        setIsLoading(false);
      }
    };

    fetchMajors();
  }, []);

  // تصفية التخصصات حسب الكلية المختارة
  const filteredMajors = selectedCollege
    ? majors.filter(major => major.collegeSlug === selectedCollege)
    : [];

  if (isLoading) {
    return <div className={styles.loading}>جاري تحميل التخصصات...</div>;
  }

  return (
    <section id="admission-requirements" className={styles.majorsSection}>
      <div className={styles.container}>
        <motion.div
          className={styles.sectionHeader}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className={styles.sectionTitle}>التخصصات وشروط القبول</h2>
          <p className={styles.sectionDescription}>
            تعرف على التخصصات المتاحة وشروط القبول في كل تخصص
          </p>
        </motion.div>

        {selectedCollege ? (
          // عرض زر العودة عند اختيار كلية
          <div className={styles.backButtonContainer}>
            <button 
              className={styles.backButton}
              onClick={() => setSelectedCollege('')}
            >
              العودة إلى الكليات
            </button>
            <h3 className={styles.selectedCollegeTitle}>
              {colleges.find(c => c.slug === selectedCollege)?.name}
            </h3>
          </div>
        ) : (
          // عرض الكليات
          <div className={styles.collegesGrid}>
            {colleges.map((college, index) => (
              <motion.div
                key={college.id}
                className={styles.collegeCard}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                whileHover={{ 
                  scale: 1.05,
                  boxShadow: '0 8px 16px rgba(0, 0, 0, 0.1)'
                }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                onClick={() => setSelectedCollege(college.slug)}
              >
                <h3 className={styles.collegeName}>{college.name}</h3>
                <div className={styles.collegeInfo}>
                  <span>اضغط للاطلاع على التخصصات المتاحة</span>
                  <div className={styles.arrowIcon}>→</div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* شبكة التخصصات - تظهر فقط عند اختيار كلية */}
        {selectedCollege && (
          <div className={styles.majorsGrid}>
            {filteredMajors.map((major, index) => (
            <motion.div
              key={major.id}
              className={styles.majorCard}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              whileHover={{ 
                scale: 1.02,
                boxShadow: '0 8px 16px rgba(0, 0, 0, 0.1)'
              }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
            >
              <div className={styles.majorHeader}>
                <span className={styles.majorIcon}>{major.icon}</span>
                <div className={styles.majorTitles}>
                  <h3 className={styles.majorName}>{major.name}</h3>
                  <span className={styles.majorCollege}>{major.college}</span>
                </div>
              </div>

              <p className={styles.majorDescription}>{major.description}</p>
              
              <div className={styles.majorInfo}>
                <div className={styles.majorDuration}>{major.duration}</div>
                <div className={styles.majorStudents}>{major.students} طالب/ة</div>
              </div>
              
              <div className={styles.majorFeatures}>
                <h4 className={styles.featuresTitle}>المميزات:</h4>
                <ul className={styles.featuresList}>
                  {major.features.map((feature, idx) => (
                    <li key={idx} className={styles.featureItem}>✓ {feature}</li>
                  ))}
                </ul>
              </div>
              
              <div className={styles.admissionRequirements}>
                <h4 className={styles.requirementsTitle}>شروط القبول:</h4>
                <ul className={styles.requirementsList}>
                  {major.admissionRequirements.length > 0 ? (
                    major.admissionRequirements.map((requirement, idx) => (
                      <li key={idx} className={styles.requirementItem}>{requirement}</li>
                    ))
                  ) : (
                    <li className={styles.noRequirements}>لم يتم تحديد شروط القبول بعد</li>
                  )}
                </ul>
              </div>
              
              <Link 
                href="#registration-form" 
                className={styles.applyButton}
              >
                تقديم طلب الالتحاق
              </Link>
            </motion.div>
          ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default MajorsGrid;
